package com.eventManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eventManagementSystem.model.Event;

@Repository
public interface EventRepository extends JpaRepository<Event, Long>{ 

	
	public List<Event> findByEventName(String eventName);
	public Event getByEventName(String eventName);
}
