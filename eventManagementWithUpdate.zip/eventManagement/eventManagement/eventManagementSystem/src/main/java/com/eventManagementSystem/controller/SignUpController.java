package com.eventManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;

import com.eventManagementSystem.model.Credentials;
import com.eventManagementSystem.repository.CredentialsRepository;

@Controller
public class SignUpController {

	@Autowired
	private CredentialsRepository credRepo;


	@RequestMapping(value="/",method=RequestMethod.GET)
	public String viewv()
	{
		return "SignUp";
	}
	@RequestMapping(value="/",method=RequestMethod.POST)
	public String signup(@RequestParam String username ,
			@RequestParam String password,@RequestParam String role)
	{
		Credentials cred=new Credentials(username,password,role);
		credRepo.save(cred);
		return "redirect:log-in";
	}
	
}
