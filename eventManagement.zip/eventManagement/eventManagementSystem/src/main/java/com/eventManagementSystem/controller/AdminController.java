package com.eventManagementSystem.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.eventManagementSystem.model.Event;
import com.eventManagementSystem.model.User;
import com.eventManagementSystem.repository.EventRepository;
import com.eventManagementSystem.repository.UserRepository;
import com.eventManagementSystem.repository.UserRepository;

@Controller
public class AdminController {


	@Autowired
	private EventRepository eventRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	
	
	@RequestMapping(value="/add-event",method=RequestMethod.GET)
	public String addEvent()
	{
		return "AddEvent";
	}
	
	@RequestMapping(value="/add-event",method=RequestMethod.POST)
	public String addEventt(@RequestParam String Id,@RequestParam String EName,@RequestParam String EDesc,
			@RequestParam String ven,@RequestParam String EDate,@RequestParam String avail)
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		  

		  //convert String to LocalDate
		  LocalDate localDate = LocalDate.parse(EDate, formatter);
		  
		  boolean avv=false;
			if(avail.equalsIgnoreCase("true"))
			{
				avv=true;
			}
		
			Event event=new Event(Long.parseLong(Id),EName,EDesc,ven,localDate,avv);
			eventRepo.save(event);
		
		return "redirect:admin-dashboard";
	}
	
	@RequestMapping("/admin-dashboard")
	public String DashBoardview(Model model)
	{
		List<Event>list=eventRepo.findAll();
		model.addAttribute("list", list);
		return "AdminDashBoard";
		
	}
	
	@RequestMapping(value="/delete-event",method=RequestMethod.GET)
	public String DeleteEventt()
	{
		return "DeleteEvent";
	}
	
	@RequestMapping(value="/delete-event",method=RequestMethod.POST)
	public String DeleteEvent(@RequestParam String Id)
	{
		eventRepo.deleteById(Long.parseLong(Id));
		
		return "redirect:admin-dashboard";
	}
	
	@RequestMapping(value="/user-record",method=RequestMethod.GET)
	public String UserRecordss(Model model)
	{
		List<User>li=userRepo.findAll();
		model.addAttribute("list", li);
		
		return "UserRecords";
	}
}
