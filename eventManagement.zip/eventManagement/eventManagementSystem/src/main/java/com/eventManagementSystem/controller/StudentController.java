package com.eventManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.eventManagementSystem.model.Event;
import com.eventManagementSystem.model.User;
import com.eventManagementSystem.repository.EventRepository;
import com.eventManagementSystem.repository.UserRepository;

@Controller
public class StudentController {
	
	@Autowired
	private EventRepository eventRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@RequestMapping(value="/user-dashboard",method=RequestMethod.GET)
	public String UserDashboardView(Model model)
	{
		List<Event> list=eventRepo.findAll();
		model.addAttribute("list", list);
		return "UserDashBoard";
	}
	
	@RequestMapping(value="/select-event",method=RequestMethod.GET)
	public String selectEvent()
	{
		return "ChooseEvent";
		
	}
	
	@RequestMapping(value="/select-event",method=RequestMethod.POST)
	public String selectEventt(@RequestParam String Id,@RequestParam String UName,@RequestParam String EName,
			@RequestParam String sts,Model model)
	{
		
		List<Event>l=eventRepo.findByEventName(EName);
		System.out.println(l.size());
		Event event=eventRepo.getByEventName(EName);
		boolean chk=event.isAvailable();
		
		if(l.size()!=0 && chk) {
		
		User user=new User(Long.parseLong(Id),UName,EName,sts);
		
		userRepo.save(user);
		
		List<User> li=userRepo.findByUserName(UName);
		model.addAttribute("list", li);
		return "SelectedEvents";
		}
		return "redirect:user-dashboard";
		
		
		
	}
	
	@RequestMapping(value="/selected-event",method=RequestMethod.GET)
	public String selectDash(Model model)
	{
		List<User> li=userRepo.findAll();
		model.addAttribute("list", li);
		
		return "SelectedEvents";
	}
	
	@RequestMapping(value="/delete-selectedEvent",method=RequestMethod.GET)
	public String deleteEventt()
	{
		return "delSelectEvents";
	}
	
	@RequestMapping(value="/delete-selectedEvent",method=RequestMethod.POST)
	public String deleteEventtt(@RequestParam String Id)
	{
		userRepo.deleteById(Long.parseLong(Id));
		
		return "redirect:user-dashboard";
	}

}
