package com.eventManagementSystem.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.eventManagementSystem.model.Credentials;
import com.eventManagementSystem.model.Credentials;
import com.eventManagementSystem.model.Event;
import com.eventManagementSystem.model.User;
import com.eventManagementSystem.repository.CredentialsRepository;
import com.eventManagementSystem.repository.EventRepository;
import com.eventManagementSystem.repository.UserRepository;

@Controller
public class LoginController {

	@Autowired
	private EventRepository eventRepo;
	
	@Autowired
	private UserRepository userRepo;


	@Autowired
	private CredentialsRepository credRepo;
	
	
	@RequestMapping(value ="log-in",method=RequestMethod.GET)
	public String LogInView()
	{
		return "LoginView";
	}
	
	
	@RequestMapping(value="log-in",method=RequestMethod.POST)
	public String LoginView(@RequestParam String name,@RequestParam String pass,@RequestParam String role,Model model)
	{
		if(role.equalsIgnoreCase("admin"))
		{
			
			boolean user=credRepo.existsByUserName(name);
			boolean passW=credRepo.existsByPassWord(pass);
			boolean rolee=credRepo.existsByRole(role);
			
			boolean chk=false;
			List<Credentials>l=credRepo.findByUserName(name);
			for(Credentials i:l)
			{
				if(i.getRole().equalsIgnoreCase("admin"))
				{
					chk=true;
				}
			}
			
			if(user && passW && rolee && chk)
			{
			List<Event>list=eventRepo.findAll();
			model.addAttribute("list", list);
			return "AdminDashBoard";
			}
			
			else
			{
				model.addAttribute("error", "Invalid Credentials");
				return "LoginView";
			}
		}
		
		else
		{
			
			boolean user=credRepo.existsByUserName(name);
			boolean passW=credRepo.existsByPassWord(pass);
			boolean rolee=credRepo.existsByRole(role);
			
			boolean chk=false;
			List<Credentials>l=credRepo.findByUserName(name);
			for(Credentials i:l)
			{
				if(i.getRole().equalsIgnoreCase("user"))
				{
					chk=true;
				}
			}
			
			if(user && passW && rolee)
			{
			
			List<User> li=userRepo.findByUserName(name);
			if(li.size()!=0)
			{
			model.addAttribute("list", li);
			return "SelectedEvents";
			}
			
			else
			{
				return "redirect:user-dashboard";
			}
			}
			
			else
			{
				model.addAttribute("error", "Invalid Credentials");
				return "LoginView";
			}
			
			
		}
	}
	
	
	
}
